/*============== typing animation ============== */
var typed = new Typed(".typing",{
    strings:["Web Designer","Frontend Developer"," Data Scientist","ML engineer"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})